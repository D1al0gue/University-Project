// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a COMP103 assignment.
// You may not distribute it in any other way without permission.

/* Code for COMP103 - 2023T3, Assignment 4
 * Name:
 * Username:
 * ID:
 */

/**
 * Implements a binary tree that represents the Morse code symbols, named after its inventor
 *   Samuel Morse.
 * Each Morse code symbol is formed by a sequence of dots and dashes.
 *
 * A Morse code chart has been provided with this assignment. This chart only contains the 26 letters
 * and 10 numerals. These are given in alphanumerical order. 
 *
 */

import ecs100.*;
import java.util.*;
import java.io.*;
import java.nio.file.*;

public class MorseCode {

    public SymbolNode root = new SymbolNode(null,           // root of the morse code binary tree;
                                            new SymbolNode("E",                             
                                                           new SymbolNode("I"),
                                                           new SymbolNode("A")),
                                            new SymbolNode("T",                             
                                                           new SymbolNode("N"),
                                                           new SymbolNode("M")));

    /**
     * Setup the GUI and creates the morse code with characters up to 2 symbols
     */
    public static void main(String[] args){
        new MorseCode().setupGUI();

        //WRITE HERE WHICH PARTS OF THE ASSIGNMENT YOU HAVE COMPLETED
        // so the markers know what to look for.
        UI.println("""
         Replace this text (in the main method):
         I have not done this assignment; I should not get any marks.   :)
      
         --------------------
         """);
         
    }

    /**
     * Set up the interface
     */
    public void setupGUI(){
        UI.addButton("Print Tree", this::printTree);
        UI.addTextField("Decode ", this::decode);
        UI.addTextField("Add Code (Core)", this::addCodeCore);
        UI.addTextField("Add Code (Compl)", this::addCodeCompl);
        UI.addButton("Load File", this::loadFile);
        UI.addButton("Reset", ()->{root = new SymbolNode();});
        UI.addButton("Quit", UI::quit);
        UI.setWindowSize(1000,400);
        UI.setDivider(0.25);
    }

    
    /**
     * Decode a code by starting at the top (root), and working
     * down the tree following the dot or dash nodes according to the
     * code
     */
    public void decode(String code) {
        if ( ! isValidCode(code)){return;}
        /*# YOUR CODE HERE */

    }

    /**  
     * Print out the contents of the decision tree in the text pane.
     * The root node should be at the top, followed by its "dot" subtree, and then
     * its "dash" subtree.
     * Each node should be indented by how deep it is in the tree.
     * Needs a recursive "helper method" which is passed a node and an indentation string.
     *  (The indentation string will be a string of space characters plus the morse code leading
     *  to the node)
     */
    public void printTree(){
        /*# YOUR CODE HERE */

    }

    /**
     * Add a new code to the tree (as long as it will be in a node just below an existing node).
     * Follows the code down the tree (like decode)
     * If it finds a node for the code, then it reports the current symbol for that code
     * If it it gets to a node where there is no child for the next . or - in the code then
     *  If this is the last . or - in the code, it asks for a new symbol and adds a new node
     *  If there is more than one . or - left in the code, it gives up and says it can't add it.
     * For example,
     *  If it is adding the code (.-.) and the tree has "A" (.-) but doesn't have (.-.),
     *   then it should ask for the symbol (R) add a child node with R
     *  If it is adding the code (.-..) and the tree has "A" (.-) but doesn't have (.-.),
     *   then it would not attempt to add a node for (.-..) (L) because that would require
     *   adding more than one node.
     */
    public void addCodeCore (String code) {
        /*# YOUR CODE HERE */

    }

    // COMPLETION ======================================================
    /**
     * Grow the tree by allowing the user to add any symbol, whether there is a path leading to it.
     * Like addCodeCore, it starts at the top (root), and works its way down the tree
     *  following the dot or dash nodes according to the given sequence of the code.
     * If an intermediate node does not exist, it needs to be created with a text set to null.
     */
    public void addCodeCompl(String code) {
        /*# YOUR CODE HERE */

    }

    /** 
     * Load a collection of symbols and their codes from a file
     * Each line contains the symbol and the corresponding morse code.
     */
    public void loadFile () { 
        /*# YOUR CODE HERE */


    }


    // Utility methods ===============================================

    /**
     * Checks whether the code is a sequence of . and - only.
     */
    public boolean isValidCode (String code) {
        if (code.equals("")){
            UI.println("Code is empty");
            return false;
        }
        for (int index=0; index<code.length(); index++){
            char c = code.charAt(index);
            if (c != '-' && c != '.'){
                UI.println("Code has an invalid character: "+c);
                return false;
            }
        }
        return true;
    }
}
