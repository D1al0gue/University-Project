# Progress Report

## week 1: May 1 - May 7

|    Day    | Progress                                                                                                                  |
| :-------: | :------------------------------------------------------------------------------------------------------------------------ |
|  Monday   |                                                                                                                           |
|  Tuesday  |                                                                                                                           |
| Wednesday | Collected the robot parts and tan tests to ensure that the parts are all working, met the team and got to know each other |
| Thursday  | Successfully wrote the code to open the gate.                                                                             |
|  Friday   |                                                                                                                           |


## Week 2: May 8 - May 14
|    Day    | Progress                                                                                                                                               |
| :-------: | :----------------------------------------------------------------------------------------------------------------------------------------------------- |
|  Monday   | Started on roadmap, progress plan, software plan and core code.                                                                                        |
|  Tuesday  | Continue roadmap, built motor control file, built line detection                                                                                       |
| Wednesday | Finished building robot, put all of the core code together and tested and finished core. Code needs to be transferred from raspberry pi to repository. |
| Thursday  | Started on completion code and worked on roadmap, documented wednesday's progress                                                                      |
|  Friday   | Finished progress plan and software plan                                                                                                               |
## Week 3: May 15 - May 21
|    Day    | Progress                                                                                                                                                                                  |
| :-------: | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
|  Monday   | No meeting. Doing other course work.                                                                                                                                                      |
|  Tuesday  | No meeting. Doing other course work.                                                                                                                                                      |
| Wednesday | Built basic outline for challenge - cylinder, theoretically finished completion code, still need to debug and test it                                                                     |
| Thursday  | Figured out that there's something wrong with core and rewriting it with testing, properly finishing core, work on more completion. Robot now follows line smoothly and does not miss it. |
|  Friday   | Thinking and planning about how to approach challenge. Rewrote some functions to be reused on multiple quadrants.                                                                                                                            |
## Week 4: May 22 - May 28
|    Day    | Progress                                                                                                                                                                                                                            |
| :-------: | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
|  Monday   | Debug row and column issue, thought of a new idea for quad 4 and restarted quad 4, rewrote quad 3 using a different algorithm. Robot can now mostly turn corners                                                                    |
|  Tuesday  | debugged Completion and fixed some issue with the function, especially the turning function. Having one error measurement was not accurate enough, added a second error check and adjusted for the largest. It turns perfectly now. |
| Wednesday |                                                                                                                                                                                                                                     |
| Thursday  | Finished challegne quadrant, and ft2inished quadramt push ball                                                                                                                                                                                                         |
|  Friday   |                                                                                                                                                                                                                                     |
## Week 5: May 29 - June 3
|    Day    | Progress |
| :-------: | :------- |
|  Monday   |          |
|  Tuesday  |          |
| Wednesday |          |
| Thursday  |          |
|  Friday   |          |
