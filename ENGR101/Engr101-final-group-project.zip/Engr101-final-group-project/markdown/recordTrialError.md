# Hardware
8/10/2023 - David and Ming

We connected a t junction to the wheels and connected the t junction onto the motors.

For the camera motor, it is a bit more difficult because we need the camera to go up and down instead of spin in a circle. To accomplish this, we added two L joints motor and connected it ti the camera.

For the main body, we need the camera to be 8-10cm above the ground so and also have room for the pi and the battery. The design that we came up with is a two story popsticle stick design with the pi on the botton and the battery on the top. This way, we can have the camera adequately high up as well have room for the pi and battery.

10/5/2023 - Ming

Unfortunately, this design did not work because we did not take into account of the ports on the Pi. Because of this, we put the battery on the bottom and the pi on the top.

To connect the two platforms we used 4 popsticle sticks to hold the two platforms with parts of the popsticle stick sticking up and down the platforms.

We then used the popsticle that protrudes down to attatch the movement motors to the vehicle.

For the camera motor we attatched two popsticle sticks horiontally on the front of the vehicle and we drilled holes in the popsticle stick to screw on the motor.

We secured the pi into the vehicle by drilling holes into the platform and screwing the pi and platform together.

We secured the battery into the vehicle by making fence using popsticle sticks.

During the installation of the camera motor, we made a miatake in that the camera motor can only turn a certain amount. We installed the camera motor in the middle of the rotation so it doesn't have enough space to turn upright. To fix this, we tested the range of motion for the motor with code and set the default position (flat) for the camera to be the lowest range so that thhe motor can turn upright.

# Iota function 
9/5/2023 Gihan

I coded quadrant 2 getting the pixel value in the middle of the code. I then set the pixel to equal to 0 for nonblack and 1 for black. Then created a second array using iota which initialises index - middle. I then multiplied it with the first array and added all the results to get the scalar / inner product.

# Motor control
10/5/2023 - Gihan

I did the outline for how we will adjust the motor. Initially I was just going to use if statements to adjust the motors left and right; if to_far_left   ---> Full turn right.

However, I realised this wouldn't work as the robot was too light and because of inertia would constantly turn past where we needed it to turn. So to combat this I started on a PID adjustment routine. I initialized  KP, KD, and Error variables and then calculated the derivative of the error. I used these variables to outline the adjustment method.

The formula is kp * error + kd * derivitaive.

Next we are going to have to actually code how the motors adjust in each direction and the speed in which they adjust.

# Color testing
10/5/2023 - David

trial and error for black lines and helped clean the code
also did some research about the 3rd quadrant (completion)
looked at the RGB value of the environment: 210 R, 190 G and B. I cleaned some extra semi-colons. I researched how to know if you have switched quadrant or not if it goes from wiggly lines into sharp intersection turns.
# Quadrant 4 Outline
17/5/2023 - Gihan

I wrote out the complete code outline that we would use for Quadrant 4. We had to come up with a way to detect the different colored tubes, and then back up and the going up to the next one. The detection method involved two bounding boxes. The robot initially faces away from the tubes, so as long as there is no tube detected it would turn right. The inner bounding box would detect the tube from far away and continuosly move forward until it's close enough to get detected by the outer box. Once te outerbox is detected it that means that the robot has gotten close enough and it can now back out.
We could then copy this same detection algorithim for the other two tubes.







# weird qudrant 2 error
18/05/2023 - Sofia

the old code that we had in week 1 stopped working but everything looked fine, we tried to debug it for a few hours and it it didn't do anything so we just decided to restart quad from scratch using what we know and the new version worked.