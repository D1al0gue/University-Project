# Software Plan

This is the plan for the program. We can keep track of what does what in here so that it's easy to fix later. These are a guide for working on the program, not strict rules. Modify these when needed, but make sure to document your changes in the commit. If you add more functions to the code you should describe them here!

## Motor Controls

There should be a `motorcontrols.cpp` file and corresponding `motorcontrols.hpp` header. This should contain functions for moving the robot. The idea is that later on we can just call functions like `move_forward()` to move the robot, rather than messing with the hardware directly.

| Function                     | Input                   | Output | Description                                                                                |
| :--------------------------- | :---------------------- | :----- | :----------------------------------------------------------------------------------------- |
| `move_forward`               | `int msec`              | None   | Spins both motors forwards, for the specified milliseconds.                                |
| `move_backward`              | `int msec`              | None   | Spins both motors backwards, for the specified milliseconds.                               |
| `turn_left`                  | `int msec`              | None   | Spins the right motor forward and the left motor backward, for the specified milliseconds. |
| `turn_right`                 | `int msec`              | None   | Spins the left motor forward and the right motor backward, for the specified milliseconds. |
| `stop_blue`                  | None                    | None   | Stops the blue motors (setting to 48)                                                      |
| `reset_view`                 | None                    | None   | Sets the black motor (camera angle) to its starting position: Looking down                 |
| `turn_camera`                | `unsigned char val`     | None   | Turns the camera according to the given value                                              |
| `void motors_use_adjustment` | `double kp, double adj` | None   | Uses the adjusment and Kp to adjust the motors. With an adjustment of 0 it'll go forward.  |

## Opening the Gate

This should be just one function that contacts the server. It should return a boolean depending on if there was an error or not. The purpose of this boolean is to stop the vehicle from ramming into the closed gate

| Function    | Input | Output        | Description                                                         |
| :---------- | :---- | :------------ | :------------------------------------------------------------------ |
| `open_gate` | None  | `bool result` | Opens the gate, returns true after sending messages back and forth. |

## Following the curved Line

Following the curved line will require two functions. One for detecting how many black pixels are there, and then for calculating the adjustment based on that. The adjustment should be calculating the inner product algorithm.

| Function                    | Input | Output              | Description                                                                                 |
| :-------------------------- | :---- | :------------------ | :------------------------------------------------------------------------------------------ |
| `count_centre_black_pixels` | None  | `int count`         | Returns how many black pixels there are in the middle row of the camera.                    |
| `calculate_adjustment`      | None  | `double adjustment` | Calculates how much to pass to `motors_use_adjustment` to align the robot towards the line. |


## Solving the maze

The beginning of the quadrant will be marked with a red piece of paper. There should be a function that counts how many of any colour are in the screen.

| Function            | Input    | Output      | Description                                                                              | 
| :------------------ | :------- | :---------- | :--------------------------------------------------------------------------------------- |
| `count_color_pixel` | `char c` | `int count` | Takes in either `'r'`, `'g'`, or `'b'`, and counts how many of those pixels are in the camera. |


### Detecting junction

| Function            | Input      | Output               | Description                                                                                                        | 
| :------------------ | :-----     | :------------------- | :----------------------------------------------------------------------------------------------------------------- |
| `detect_junction`   | None       | `vector<bool> edges` | Returns a vector with booleans for the left, top, and right sides depending on if there are black pixels or not.   |
| `turn_to_line`      | `char dir` | None                 | Takes in either `'r'` for right or `'l'` for left or `t` for 180 degrees turn and turns the robot until the line on that side points forwards. |

## Approaching Tubes

We can reuse the function that counts color pixels.

| Function                     | Input    | Output | Description                                                                                     |
| :--------------------------- | :------- | :----- | :---------------------------------------------------------------------------------------------- |
| `approach_tube`              | None     | None   | Gets the adjustment and approaches the tube until close enough.                                 |
| `calculate_color_adjustment` | `char c` | None   | Calculates the adjustment towards the given colour. `c` would be either `'r'`, `'g'`, or `'b'`. |

## Pushing the Ball

Most of this can be done re-using previous functions like color adjustment, and color count.

| Function    | Input | Output | Description                                                    |
| :---------- | :---- | :----- | :------------------------------------------------------------- |
| `push_ball` | None  | None   | Goes towards the ball and pushes it until it's off the screen. |
 
