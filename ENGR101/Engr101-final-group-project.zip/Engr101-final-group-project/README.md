# Kachow Project plan
See `softwareplan.md` for detailed breakdowns of functions and code plan. [Software Plan](markdown/softwareplan.md).

Progress report can be found at [in the markdown folder](markdown/progressreport.md).
# Roles:
- Sofia - System architect and reporter
  - Designs software plan and records what we have done throughout the project
  - Contact: `mezasdieg@myvuw.ac.nz`
- Ming - Group Leader and hardware architect
  - Manages personnel and in charge of dealing with any hardware issues
  - Contact: `baoming@myvuw.ac.nz`
- Gihan - Coder and reporter
  - Code as well as report things that we did throughout the project
  - Contact: `bandargiha@myvuw.ac.nz`
- David - Coder
  - Main coder
  - Contact: `nangoidavi@myvuw.ac.nz`
 nangoidavi@myvuw.ac.nz
# General Progress Plan

|   Week    | Start Date | End Date | Objective                                                                                | All                                                                                                            | Ming                                       | Gihan                  | Sofia                                  | David                                                |
| :-------: | :--------: | :------: | :--------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------- | :----------------------------------------- | :--------------------- | :------------------------------------- | :--------------------------------------------------- |
|     1     |   may 1    |  may 7   | Collect hardware, get to know the team, start on planning the project                    | Get hardware and project box, test hardware to make sure they're all functioning                               | make draft of project plan                 | create gitLab project  | create makefile and test Pi connection | get familiar with the code required for the project  |
|     2     |   may 8    |  may 14  | Finish planning project, build vehicle, plan code, start coding                          | Build vehicle and start on core                                                                                | Plan/build vehicle and finish project plan | Work on core code      | Create software plan and testing plan  | Build vehicle and code, work on core if there's time |
|     3     |   may 15   |  may 21  | Finish and test core, complete most of completion                                        | Finish core and start on completion                                                                            | work on core code and test core            | Work on core code      | debug and test core code               | work on completion code                              |
|     4     |   may 22   |  may 28  | Finish completion and get started on challange, make sure that core and completion works | Finish completion and do extensive test with core and completion, start on challange if tests are satisfactory | test completion code                       | finish completion code | test an debugg completion code         | finish completion code                               |
| 5 - final |   may 29   |  june 3  | Get as much challange done as possible and final testing                                 | Work on challange code                                                                                         | Work on challange code                     | Work on challange code | Work on challange code                 | Work on challange code                               |

# Weekly plan
## week 1: May 1 - May 7

Get to know the team and get basic hardware.
## Week 2: May 8 - May 14
Conflicts:
- COMP 102 Pass/Fail 6
- ENGR 121 Assignment 5

| personnel      | Timeframe                            | objective                                                           |
| -------------- | ------------------------------------ | ------------------------------------------------------------------- |
| Ming           | End of Monday                        | Finish project plan                                                 |
| Ming           | End of Tuesday                       | Finish weekly plans                                                 |
| Ming and David | End of Wednesday, latest end of week | Plan and build the vehicle                                          |
| David          | End of Monday                        | Create Function that opens the gate                                 |
| Sofia          | End of Tuesday                       | Finish software plan                                                |
| Sofia          | End of Wednesay                      | Start and finish testing plan                                       |
| Gihan          | End of Monday                        | Create function that detects black pixels and puts them in an array |
| David          | End of Tuesday                       | IOTA function as well as image processing Q2                        |
| Gihan          | End of Friday                        | Create function for motor control                                   |
| Sofia, David   | End of friday                        | Record everything that we did this week                             |

## Week 3: May 15 - May 21
Conflicts:
- ENGR 121 Assignment 6

| personnel       | Timeframe        | objective                                                                            |
| --------------- | ---------------- | ------------------------------------------------------------------------------------ |
| Ming            | End of monday    | Finish any leftover core code from last week                                         |
| David           | End of monday    | Debug the core code                                                                  |
| Sofia           | End of monday    | Put the core functions together                                                      |
| Gihan           | End of wednesday | work on image junction detection function                                            |
| Sofia and David | End of wednesday | Trial and error with qudrant 2 code, work on finding what the perfect KP and KD is   |
| Ming            | End of friday    | Work on making code that turns the vehicle 90 degrees left/right and 180 degree turn |
| Gihan           | End of friday    | Put the code that we have for completion together in main                            |

## Week 4: May 22 - May 28
Conflicts:
- ENGR 121 Assignment 7
- COMP 102 Assignment 7
- CYBR 171 Assignment 2

| personnel | Timeframe               | objective                                                                                    |
| --------- | ----------------------- | -------------------------------------------------------------------------------------------- |
| Sofia     | End of tuesday          | Create function that detects the change in qudrants and updates main                         |
| All       | End of wednesday        | Extensive testing on core and completion code                                                |
| Ming      | Continue into next week | Create function that detects the right tube to approach, in the order of Red, Blue and Green |
| David     | Continue into next week | Create function that stops before actually touching the tube                                 |
| Gihan     | Continue into next week | Create function that pushes the block off the table                                          |
| Sofia     | Continue into next week | Create function that moves vehicle towards the tubes                                         |

## Week 5: May 29 - May 31
Conflicts:
- Life
- Tax fraud ツツ
| personnel | Timeframe        | objective                                 |
| --------- | ---------------- | ----------------------------------------- |
| ALL       | End of monday    | Finish functios that started last week    |
| ALL       | End of tuesday   | final test and debugging                  |
| ALL       | End of wednesday | End of development, get ready for marking |
