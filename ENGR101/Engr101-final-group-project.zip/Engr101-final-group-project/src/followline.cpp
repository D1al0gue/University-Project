#include "followline.hpp"
#include "E101.h"
#include "motorcontrols.hpp"
#include <cmath>
#include <iostream>
#include <numeric>

/*
 * Simple function for determining if the pixel is dark enough.
 */
bool is_black(unsigned char l) { return l < 55; }

/*
 * Returns true if the given RGBL value is the color of the second argument.
 * The possible colours are:
 * r: red
 * g: green
 * b: blue
 */
bool is_color(unsigned char r, unsigned char g, unsigned char b, char rgb) {
    switch (rgb) {
    case 'r':
//        return ((int)r*5>(int)b*4)&&((int)r*5>(int)g*4);
        return r > g + 10 && r > b + 10 && r > 90 && g < 100;
        break;

    case 'g':
        return g > r + 5 && g > b + 5;
        break;

    case 'b':
        return b > r + 3 && b > g + 3;
        break;
    }
    return false;
}

/*
 * Counts how many pixels of the given colour are at the selected row.
 * Colour is determined via the is_color function.
 */
int count_pixels(int row, char rgbk) {
    int count = 0;

    // Go through each pixel
    for (int col = 0; col < CAMERA_WIDTH; col++) {
        // Get the values of that pixel
        unsigned char r = get_pixel(row, col, 0);
        unsigned char g = get_pixel(row, col, 1);
        unsigned char b = get_pixel(row, col, 2);

        switch (rgbk) {
        case 'k':
            if (is_black(get_pixel(row, col, 3)))
                count++;
            break;

        default:
            // Count up if it's actually the given colour.
            if (is_color(r, g, b, rgbk))
                count++;
        }
    }

    return count;
}

int get_error(int row, char color) {
    // Array has a 0 if that pixel is white, 1 otherwise.
    int has_color[CAMERA_WIDTH] = {};

    for (int col = 0; col < CAMERA_WIDTH; col++) {
        bool is_c = false;

        if (color == 'k')
            is_c = is_black(get_pixel(row, col, 3));
        else {
            unsigned char r = get_pixel(CAMERA_HEIGHT / 2, col, 0);
            unsigned char g = get_pixel(CAMERA_HEIGHT / 2, col, 1);
            unsigned char b = get_pixel(CAMERA_HEIGHT / 2, col, 2);
            is_c = is_color(r, g, b, color);
        }

        if (is_c) {
            has_color[col] = 1;
        } else {
            has_color[col] = 0;
        }
        
    }

    // The array with -2, -1, 0, 1, 2, etc.
    int nums[CAMERA_WIDTH] = {};
    std::iota(nums, nums + CAMERA_WIDTH, -CAMERA_WIDTH / 2);

    // Multiply each array by the other
    int error = 0;
    for (int x = 0; x < CAMERA_WIDTH; x++) {
        error += has_color[x] * nums[x];
    }

    return error;
}

void follow_line(int base, char c, int row) {
    int color_pixels = count_pixels(row, c);

    if (color_pixels == 0) {
        // We've lost the line
        // Try and back up and fix stuff
        return;
    }

    int error = get_error(row, c);
    // Store previous error so we can calculate the gradient.
    static int prev_error = 0;

    // How much the error has changed since the last time.
    static int derivative = error - prev_error;

    // Derivative coefficient
    double kd = 0.0003;

    // Error coefficient
    double kp = 0.055;

    double adjustment = kp * error + kd * derivative;

    // std::cout << "Derivative: " << kd * derivative << "\n";

    prev_error = error;

    // Divide by how many black pixels are on the screen
    // for when the line is on the edge
    adjustment /= (double)color_pixels;

    // Saving to a variable in case we want to print it
    int round_adjustment = std::round(adjustment);

    // std::cout << round_adjustment << "\n";

    // The second number is the default state of the motors.
    // In this case we want to move forward (positive)
    motors_use_adjustment(round_adjustment, base);
}
