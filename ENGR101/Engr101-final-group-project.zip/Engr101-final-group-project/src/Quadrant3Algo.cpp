#include "E101.h"
#include "followline.hpp"
#include "motorcontrols.hpp"
#include "quadrant3.hpp"
#include <cmath>
#include <iostream>
#include <vector>

using namespace std;

// The maximum luminosity a pixel can be before it's not black
const unsigned char max_lum = 55;

int count_black_centre_row() {
    int count = 0;
    // Go through each pixel in the middle (relative to the camera)
    for (int col = 0; col < CAMERA_WIDTH; col++) {
        int lum = get_pixel(CAMERA_HEIGHT / 2, col, 3);
        if (lum < max_lum)
            count++;
    }
    return count;
}

int count_black_left_col() {
    int count = 0;
    // Go through each pixel on the left ( relative to the camera)
    for (int row = 0; row < CAMERA_HEIGHT; row++) {
        int lum = get_pixel(row, CAMERA_WIDTH - 5, 3);
        if (lum < max_lum)
            count++;
    }
    return count;
}

int count_black_right_col() {
    int count = 0;
    // Go through each pixel on the right ( relative to the camera )
    for (int row = 0; row < CAMERA_HEIGHT; row++) {
        int lum = get_pixel(row, CAMERA_WIDTH - 315, 3);
        if (lum < max_lum)
            count++;
    }
    return count;
}

void turn_to_line_left() {
    // Turn initially
    turn_left(450);

    const int mid_row = CAMERA_HEIGHT / 2;
    const int bot_row = CAMERA_HEIGHT - 15;

    // Just some values to get the loop started, they don't really matter
    int err_mid, err_bot;
    int err = 400;
    int black_px = 400;

    while (err > 20 || black_px <= 20) {
        // Update screen
        take_picture();

        // See how many pixels there are
        black_px = count_pixels(CAMERA_HEIGHT / 2, 'k');

        // Avoid division by 0
        // The purpose of this so to try and get the line straight
        err_mid = abs(get_error(mid_row, 'k')) / ((black_px) ? black_px : 1);

        err_bot = abs(get_error(bot_row, 'k')) / ((black_px) ? black_px : 1);

        err = max(err_mid, err_bot);

        // Not enough black pixels, turn a bit and try again
        if (black_px < 10) {
            motors_use_adjustment(-4, 0);
        } else {
            // We've found enough of the line, let's align the robot to it
            // NOTE! I feel like it would be better with a 1 or something,
            // but let's decide that over testing
            if (err_bot > err_mid) {
                follow_line(1, 'k', bot_row);
            } else {
                follow_line(1, 'k', mid_row);
            }
        }
    }
    //std::cout << "Back\n";
}
void turn_to_line_right() {
    // Turn initially
    turn_right(450);

    const int mid_row = CAMERA_HEIGHT / 2;
    const int bot_row = CAMERA_HEIGHT - 15;

    // Just some values to get the loop started, they don't really matter
    int err_mid, err_bot;
    int err = 400;
    int black_px = 400;

    while (err > 20 || black_px <= 20) {
        // Update screen
        take_picture();

        // See how many pixels there are
        black_px = count_pixels(CAMERA_HEIGHT / 2, 'k');

        // Avoid division by 0
        // The purpose of this so to try and get the line straight
        err_mid = abs(get_error(mid_row, 'k')) / ((black_px) ? black_px : 1);

        err_bot = abs(get_error(bot_row, 'k')) / ((black_px) ? black_px : 1);

        err = max(err_mid, err_bot);

        //std::cout << err << "\t" << black_px << "\n";

        // Not enough black pixels, turn a bit and try again
        if (black_px < 10) {
            motors_use_adjustment(4, 0);
        } else {
            // We've found enough of the line, let's align the robot to it
            // NOTE! I feel like it would be better with a 1 or something,
            // but let's decide that over testing
            if (err_bot > err_mid) {
                follow_line(1, 'k', bot_row);
            } else {
                follow_line(1, 'k', mid_row);
            }
        }
    }

    //std::cout << "Back\n";
}

bool go_though_maze() {
    // These are the instructions, we'll pop one at each intersection.
    // NOTE: These are reversed. The last instruction in here will be the first
    // one performed
    static vector<char> instructions = {'R', 'L', 'R', 'L', 'L', 'R', 'R'};

    follow_line(4, 'k', CAMERA_HEIGHT / 2);

    // Check for intersection
    bool intersection =
        count_black_left_col() > 10 || count_black_right_col() > 10;

    // This prints if it detects a line on the left or right
    // std::cout <<  (count_black_left_col() > 0) << "\t" <<
    // (count_black_right_col() >0) << "\n";

    if (intersection && instructions.size() > 0) {
        // Go forward until we don't see the lines anymore.
        // This is we're on the corner when we turn
        int botrow_px;
        while ((botrow_px = count_pixels(CAMERA_HEIGHT - 3, 'k')) <= 70 &&
               botrow_px != 0) {
            take_picture();
            if (count_pixels(CAMERA_HEIGHT / 2, 'k') <= 70) {
                follow_line(0, 'k', CAMERA_HEIGHT / 2);
            }
            move_forward(150);
        }

        // Pop the last instruction
        char inst = instructions.at(instructions.size() - 1);
        instructions.pop_back();

        // This is what we're doing rn
        //std::cout << "Instruction received: " << inst << std::endl;

        if (inst == 'R') {
            turn_to_line_right();
        } else {
            turn_to_line_left();
        }
    }

    // Just in case
    return instructions.size() == 0;
}
