//idk why i named it like this

/* red code, just without stopping
*/
#include "E101.h"
#include "followline.hpp"
#include "motorcontrols.hpp"
#include "quadrant4.hpp"
#include <numeric>
#include <cmath>
#include <iostream>

using namespace std;

bool red_ball_is_there(){
    take_picture();
    int redAmount = 0;

    for (int row = 0 ; row < 240 ; row++) {
		for (int col = 0; col < 320; col++) {
			//detects the amount of red in the frame
	//		if ((int)get_pixel(row,col,0)*3 > (int)get_pixel(row,col,1)*4 &&  
	//			(int)get_pixel(row,col,0)*3 > (int)get_pixel(row,col,2)*4){
	if (is_color(get_pixel(row,col,0),get_pixel(row,col,1), get_pixel(row,col,2), 'r')) {

				redAmount = redAmount+1;
			}
		}
	}
		//std::cout << redAmount <<"\n";

    if (redAmount > 72600){
        return false;
    } else {
        return true;
    }
}



void quad_push_ball(){
    //look for red
    move_backward(2000);
    //turn_left(500);

    //while(lookForRed()){
    while(!red_ball_is_there()){
        turn_left(100);
    }
    //Go towards red
    while(red_ball_is_there()){
        follow_line(4, 'r', CAMERA_WIDTH/2);
    }

    stop_blue();

    set_camera_lowest(); //attack!
}
