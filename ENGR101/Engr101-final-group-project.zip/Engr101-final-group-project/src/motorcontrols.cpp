#include "motorcontrols.hpp"
#include "E101.h"
// The pins that each motor uses
#define MOTOR_R 1
#define MOTOR_L 3
#define MOTOR_CAMERA 5

// Where the motor stops
#define LVL_MIDPOINT 48

void stop_blue() {
    set_motors(MOTOR_L, LVL_MIDPOINT);
    set_motors(MOTOR_R, LVL_MIDPOINT);
    hardware_exchange();
}

void move_forward(int msec) {
    set_motors(MOTOR_R, LVL_MIDPOINT + LVL_DIFF);
    set_motors(MOTOR_L, LVL_MIDPOINT - LVL_DIFF);
    hardware_exchange();

    sleep1(msec);
    stop_blue();
}

void move_backward(int msec) {
    set_motors(MOTOR_R, LVL_MIDPOINT - LVL_DIFF / 2);
    set_motors(MOTOR_L, LVL_MIDPOINT + LVL_DIFF / 2);
    hardware_exchange();

    sleep1(msec);
    stop_blue();
}
void turn_left(int msec) {
    set_motors(MOTOR_L, LVL_MIDPOINT - LVL_DIFF);
    set_motors(MOTOR_R, LVL_MIDPOINT - LVL_DIFF);
    hardware_exchange();

    sleep1(msec);
    stop_blue();
}
void turn_right(int msec) {
    set_motors(MOTOR_L, LVL_MIDPOINT + LVL_DIFF);
    set_motors(MOTOR_R, LVL_MIDPOINT + LVL_DIFF);
    hardware_exchange();

    sleep1(msec);
    stop_blue();
}

void set_camera_angle(int diff) {
    set_motors(MOTOR_CAMERA, LVL_MIDPOINT + diff);
    hardware_exchange();
}

void set_camera_highest() { set_camera_angle(17); }

void set_camera_lowest() { set_camera_angle(-18); }

void motors_use_adjustment(int adj, int base) {
    set_motors(MOTOR_R, LVL_MIDPOINT + adj + base);
    set_motors(MOTOR_L, LVL_MIDPOINT + adj - base);
    hardware_exchange();
}

void reset_view() {
    // I'm not sure of how the servo works, will need to test
    // For now i'll just set it to the midpoint.
    set_motors(MOTOR_CAMERA, LVL_MIDPOINT);
    hardware_exchange();
}
