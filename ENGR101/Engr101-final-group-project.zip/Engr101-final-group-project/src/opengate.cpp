#include "opengate.hpp"
#include "E101.h"
#include <iostream>

using namespace std;

bool open_gate() {
    char server_addr[] = "130.195.3.91"; // replace with raspberry's IP

    // the port number for the gate-opening server (came from lecture slides)
    int port = 1024;

    // Connect to the server
    int client_socket = connect_to_server(server_addr, port);
    if (client_socket == -1) {
        cerr << "Error: Failed to connect to the server" << endl;
        return false;
    }

    // Send message to open the gate
    char message[] = "Please";
    send_to_server(message);

    // Get password and send back
    char response[24];
    receive_from_server(response);
    send_to_server(response);

    return true;
}
