#include "E101.h"
#include "followline.hpp"
#include "motorcontrols.hpp" // just in case to test
#include "opengate.hpp"
#include "quadrant2.hpp"
#include "quadrant3.hpp"
#include "quadrant4.hpp"
#include "ramItDown.hpp"
#include <iostream>

bool detect_red() {
    //<= sign to make it a 5x5 pixel detection system.
    for (int i = 240 / 2 - 2; i <= 240 / 2 + 2; i++) {
        for (int j = 320 / 2 - 2; j <= 320 / 2 + 2; j++) {
            // will detect the pixel from pixel 118 to 122
            // will detect the pixel from pixel 158 to 162

            int r = get_pixel(i, j, 0);
            int g = get_pixel(i, j, 1);
            int b = get_pixel(i, j, 2);
            if (is_color(r, g, b, 'r')) {
                // red is there
                return true;
            }
        }
    }
    return false;
}

/*MOMENTaRY CODE! I'LL ELETE THIS ONCE WE TESTED RGB VaLUE FOR THE CYLINDERS*/
void check_colour() {
    for (int i = 0; i < CAMERA_WIDTH; i++) {
        for (int j = 0; CAMERA_HEIGHT; j++) {
            int red = get_pixel(j, i, 0);
            int green = get_pixel(j, i, 1);
            int blue = get_pixel(j, i, 3);
            std::cout << "RED:   " << red << std::endl;
            std::cout << "GREEN:   " << green << std::endl;
            std::cout << "BLUE:   " << blue << std::endl;
        }
    }
}

int main() {
    // Code!!
    int err = init(0);
    std::cout << "init return value is " << err << "\n";

    open_screen_stream();

    // Each Quadrant will have separate code to handle it
    enum Quadrant { GATE, CURVED_LINE, MAZE, CYLINDERS, BALL, DONE };

    Quadrant quadrant = GATE;

    while (quadrant != DONE) {
        take_picture();
        update_screen();

        switch (quadrant) {
        case GATE:
            if (!open_gate()) {
                return 1;
            }

            quadrant = CURVED_LINE;
            set_camera_lowest();
            break;

        case CURVED_LINE:
            follow_line(4, 'k', CAMERA_HEIGHT/2);

            if (detect_red()) {
                while(count_pixels(CAMERA_HEIGHT -10, 'k') < 2) {
		   follow_line(4, 'r', CAMERA_HEIGHT/2);

                    move_forward(150);
                    take_picture();
                }
                move_forward(400);
		for (int i = 0; i < 69; i++) {
		    follow_line(1, 'k', CAMERA_HEIGHT/2);
		    sleep1(50);
		    take_picture();
		}
		stop_blue();
		
		//turn_right(10); //slightly turn right
                quadrant = MAZE;
                // We're moving forward just so it goes over the red thing and
                // back to the line
            }

            break;

        case MAZE:
            go_though_maze();

            if (detect_red()) {
                quadrant = CYLINDERS;
                set_camera_highest();
            }
            break;

        case CYLINDERS:
            std::cout << "this is Quadrant cylinder"<< std::endl;
            
            quad4();

            quadrant = BALL;
            break;

        case BALL:
            // TODO! Placeholder code here
            // Turn left to adjust the camera so that it picks up the red ball
            quad_push_ball();
	    sleep1(2000);

            quadrant = DONE;

        // Will end the loop
        case DONE:
            std::cout << "We're done!\n";
            move_backward(1000);

            // Spin
            motors_use_adjustment(5, 2);
            for (int i = 0; i < 10; i++) { // ツツツ
                set_camera_highest();
                sleep1(1000);

                set_camera_lowest();
                sleep1(1000);
            }
            break;
        }
    }

    stop_blue();
    reset_view();
    return 0;
}
