/*
* Basic idea: use the  follow line code but look for the RGB colors instead
* at the end of Quad 3, look for red with follow line code
* if red is not found, look around untill red is found
* if red is find, call follow line with the argument red and move towards the red pillar
* check fir the amount of red pixels on the screen and stop once it reaches a thresh hold
* back up for X seconds and repeat for next color
* once this is done 3 times, change quadrant to 5
*/

using namespace std;
#include "E101.h"
#include "followline.hpp"
#include "motorcontrols.hpp"
#include <numeric>
#include <cmath>
#include <iostream>

// make the quad 4 code work

//functions for the red cylinder
bool lookForRed(){
    take_picture();
    int amount = 0;
    for (int i = 0; i < CAMERA_WIDTH; i++){
        unsigned char r = get_pixel(CAMERA_HEIGHT/2, i, 0);
        unsigned char g = get_pixel(CAMERA_HEIGHT/2, i, 1);
        unsigned char b = get_pixel(CAMERA_HEIGHT/2, i, 2);
	//std::printf("%d\t%d\t%d\n", r, g, b);
        if (is_color(r, g, b, 'r')) amount++;
    }
    //std::cout << amount<< "\n";
    //return true;
    if(amount > 20){
	return false;
    } else return true;
}

bool redAmount(){
    take_picture();
    int redAmount = 0;
    for (int row = 0 ; row < 240 ; row++) {
		for (int col = 0; col < 320; col++) {
			//detects the amount of red in the frame
			unsigned char r = get_pixel(row, col, 0);
			unsigned char g = get_pixel(row, col, 1);
			unsigned char b = get_pixel(row, col, 2);
			if (is_color(r, g, b, 'r')) redAmount++;
			//if ((int)get_pixel(row,col,0)*3 > (int)get_pixel(row,col,1)*4 &&  
			//    (int)get_pixel(row,col,0)*3 > (int)get_pixel(row,col,2)*4){
			//	redAmount = redAmount+1;
			//}
		}
	}
    if (redAmount > 60000){
        return false;
    } else {
        return true;
    }
}

//Function for the green cylinder
bool lookForGreen(){
    take_picture();
    int amount = 0;
    for (int i = 0; i < CAMERA_WIDTH; i++){
        unsigned char r = get_pixel(CAMERA_WIDTH/2, i, 0);
        unsigned char g = get_pixel(CAMERA_WIDTH/2, i, 1);
        unsigned char b = get_pixel(CAMERA_WIDTH/2, i, 2);
        if ((g*3>r*4)&&(g*3>b*4)) amount++;
    }
    //cout<<amount<<endl;
    if(amount > 10){
	return false;
    }else return true;
}

bool greenAmount(){
    take_picture();
    int greenAmount = 0;
    for (int row = 0 ; row < 240 ; row++) {
		for (int col = 0; col < 320; col++) {
			//detects the amount of red in the frame
			if ((int)get_pixel(row,col,1)*3 > (int)get_pixel(row,col,0)*4 &&  
			    (int)get_pixel(row,col,1)*3 > (int)get_pixel(row,col,2)*4){
				greenAmount = greenAmount+1;
			}
		}
	}
    if (greenAmount > 60000){
        return false;
    } else {
        return true;
    }
}

//Function for the blue cylinder
//the most evil of them all
bool lookForBlue(){
    take_picture();
    int amount = 0;
    for (int i = 0; i < CAMERA_WIDTH; i++){
        unsigned char r = get_pixel(CAMERA_WIDTH/2, i, 0);
        unsigned char g = get_pixel(CAMERA_WIDTH/2, i, 1);
        unsigned char b = get_pixel(CAMERA_WIDTH/2, i, 2);
        if (is_color(r, g, b, 'b')) amount++;
    }
    if(amount > 5){
	return false;
    }else return true;

}

bool blueAmount(){
    take_picture();
    int blueAmount = 0;
    for (int row = 0 ; row < 240 ; row++) {
		for (int col = 0; col < 320; col++) {
			//detects the amount of red in the frame
			if (is_color(get_pixel(row,col,0),get_pixel(row,col,1),get_pixel(row,col,2),'b')){
				blueAmount = blueAmount+1;
			}
		}
	}
    if (blueAmount > 60000){
        return false;
    } else {
        return true;
    }
}

void quad4(){
    set_camera_highest();

    turn_right(200);
    //look for red
    while(lookForRed()){
	//cout<<"look for red\n";
        turn_right(200);
	sleep1(100);
    }
    //Go towards red
    while(redAmount()){
	//cout<<"go to red\n";
        follow_line(6, 'r', CAMERA_HEIGHT/2);
    }


    //cout<<"red reached\n";
    stop_blue();
    sleep1(3000);
    move_backward(2000);
    turn_left(300);

    //look for green
    while(lookForGreen()){
	//cout<<"look for green\n";
        turn_left(100);
    }
    //Go towards green
    while(greenAmount()){
	//cout<<"go to green\n";
        follow_line(6, 'g', CAMERA_HEIGHT/2);
    }

    //cout<<"green reached\n";
    stop_blue();
    sleep1(3000);
    move_backward(2000);
    turn_right(100);

//    move_forward(500);
    //look for blue
    while(lookForBlue()){
        turn_right(300);
	//cout<<"look for blue\n";
    }
    //Go towards blue
    while(blueAmount()){
        follow_line(6, 'b', CAMERA_HEIGHT/2);
	//cout<<"go to blue\n";
    }
    
    //cout<<"blue reached\n";
    stop_blue();
    sleep1(3000);
}
