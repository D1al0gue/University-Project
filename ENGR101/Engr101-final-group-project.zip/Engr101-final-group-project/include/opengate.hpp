#pragma once
bool open_gate();
