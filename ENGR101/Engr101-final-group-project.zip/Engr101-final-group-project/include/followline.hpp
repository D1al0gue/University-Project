#pragma once

int count_pixels(int row, char rgbk);
bool is_color(unsigned char r, unsigned char g, unsigned char b, char rgb);
bool is_black(unsigned char l);
int get_error(int row, char color);

// Base is the base speed of the robot (6 if you want it to go forward at a
// reasonable speed) c is the colour to follow
int get_error(int row, char color);
void follow_line(int base, char c, int row);
