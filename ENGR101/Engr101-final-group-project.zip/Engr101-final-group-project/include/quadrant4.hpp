#pragma once

void quad4(void);

bool lookForRed(void);
