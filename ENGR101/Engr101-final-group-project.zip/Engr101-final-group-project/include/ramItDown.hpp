#pragma once

void quad_push_ball(void);