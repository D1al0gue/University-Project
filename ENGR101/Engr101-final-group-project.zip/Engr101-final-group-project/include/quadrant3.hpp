#pragma once

bool go_though_maze();

// hello
