#pragma once
void image_processing_Q2(void);
