/* Definitions for helper functions that'll control the motors */
#pragma once

void move_forward(int msec);
void move_backward(int msec);
void turn_left(int msec);
void turn_right(int msec);
void stop_blue();
void reset_view();
void set_camera_angle(int lvl);
void set_camera_highest();
void set_camera_lowest();
void motors_use_adjustment(int adj, int base);
