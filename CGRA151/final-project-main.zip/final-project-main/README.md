# CGRA151 Project Report

## Student name: [your name]
## Student ID: [your ID]
## Name of game/artwork: [no more than one line]

## Vision
[what was your vision for the game? either copy your one paragraph overview from your plan or, if your vision changed dramatically after submitting the plan, give a one paragraph description of your revised vision]

## Achievement
[in one paragraph describe what you were actually able to achieve]

## Technical Challenges
[describe the principal technical challenges that you faced; describe how you addressed those challenges; ideally you should be able to showcase two challenges that you were able to overcome]

## Reflection
[give a one paragraph reflection on your experience of doing this assignment: what was easier than expected? what was harder than expected? how well did your plan match reality? what, if anything, would you have done differently?]